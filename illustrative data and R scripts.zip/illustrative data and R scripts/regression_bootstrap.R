
# R script for regression with bootstrapping

# Below, we first illustrate modeling IM and IVAR as predictors, and 
# then illustrate modeling IM and ISD as predictors.


# IM and IVAR as predictors ----
## IM: intraindividual mean
## IVAR: intraindividual variance

## Data ----
data_IM_IVAR <- read.csv("illustration_Rscripts_data/data_IM_IVAR.csv")
# outcome
y <- data_IM_IVAR$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_IVAR[, paste0("X.", 1:TT)]

## Run ----
# 1000 bootstrap samples
nB <- 1000
# sample size 
N <- nrow(data_IM_IVAR)

# fit the regular regression model to each bootstrap sample
# and collect the estimated coefficients of IM and IVAR across all bootstrap samples. 

betas_regB <- matrix(NA, nrow = nB, ncol = 2)
colnames(betas_regB) <- c("IM", "IVAR")

set.seed(12345)
for (B in 1:nB){
    index <- sample(1:N, N, replace = TRUE)
    XB <- X[index,]
    mu.obsB <- apply(XB, 1, mean) 
    IIV.obsB <- apply(XB, 1, var)
    yB <- y[index]
    
    regIIVB <- lm(yB ~ mu.obsB+IIV.obsB)
    betas_regB[B, "IM"] <- summary(regIIVB)$coefficients[2, 1]
    betas_regB[B, "IVAR"] <- summary(regIIVB)$coefficients[3, 1]
}

# obtain the results by summarizing the coefficient estimates across bootstrap samples
regB_IM_IVAR <- data.frame(
    Predictor = c("IM", "IVAR"),
    Estimate = apply(betas_regB, 2, mean),
    Std.Error = apply(betas_regB, 2, sd),
    CI_low = apply(betas_regB, 2, quantile, 0.025),
    CI_high = apply(betas_regB, 2, quantile, 0.975)
) 

regB_IM_IVAR


# IM and ISD as predictors ----
## IM: intraindividual mean
## ISD: intraindividual standard deviation


## Data ----
data_IM_ISD <- read.csv("illustration_Rscripts_data/data_IM_ISD.csv")
# outcome
y <- data_IM_ISD$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_ISD[, paste0("X.", 1:TT)]

## Run ----
# 1000 bootstrap samples
nB <- 1000
# sample size 
N <- nrow(data_IM_ISD)

# fit the regular regression model to each bootstrap sample
# and collect the estimated coefficients of IM and ISD across all bootstrap samples. 

betas_regB <- matrix(NA, nrow = nB, ncol = 2)
colnames(betas_regB) <- c("IM", "ISD")

set.seed(12345)
for (B in 1:nB){
    index <- sample(1:N, N, replace = TRUE)
    XB <- X[index,]
    mu.obsB <- apply(XB, 1, mean) 
    IIV.obsB <- apply(XB, 1, sd)
    yB <- y[index]
    
    regIIVB <- lm(yB ~ mu.obsB+IIV.obsB)
    betas_regB[B, "IM"] <- summary(regIIVB)$coefficients[2, 1]
    betas_regB[B, "ISD"] <- summary(regIIVB)$coefficients[3, 1]
}

# obtain the results by summarizing the coefficient estimates across bootstrap samples
regB_IM_ISD <- data.frame(
    Predictor = c("IM", "ISD"),
    Estimate = apply(betas_regB, 2, mean),
    Std.Error = apply(betas_regB, 2, sd),
    CI_low = apply(betas_regB, 2, quantile, 0.025),
    CI_high = apply(betas_regB, 2, quantile, 0.975)
) 

regB_IM_ISD

