
# R script for time parceling with 1000 random occasion-to-parcel-allocations

# In this illustration, we form numpar = 3 parcels. We use the `lavaan` package to fit the model with latent IM and latent IIV.
# to install the package: 
# install.packages("lavaan")
library(lavaan)

# Below, we first illustrate modeling IM and IVAR as predictors, and 
# then illustrate modeling IM and ISD as predictors.


# IM and IVAR as predictors ----
## IM: intraindividual mean
## IVAR: intraindividual variance

## Data ----
data_IM_IVAR <- read.csv("illustration_Rscripts_data/data_IM_IVAR.csv")
# outcome
y <- data_IM_IVAR$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_IVAR[, paste0("X.", 1:TT)]

## Run ----
# 1000 random allocations, each with 3 parcels
nA <- 1000
numpar <- 3

# create vectors to collect estimates of the path coefficients and standard errors for IM and IIV
beta_mu.tpA <- se.beta_mu.tpA  <- rep(NA, nA)
beta_IIV.tpA <- se.beta_IIV.tpA <- rep(NA, nA)

# for each random allocation
set.seed(12345)
for (i in 1:nA){
    # randomly allocate occasions to 3 parcels
    nT <- round(TT/numpar)
    index.p1 <- sample(1:TT, nT, replace = FALSE)
    temp1 <- c(1:TT)[-index.p1]
    index.p2 <- sample(temp1, nT, replace = FALSE)
    temp2 <- c(1:TT)[-c(index.p1,index.p2)]
    index.p3 <- sample(temp2, (TT - 2*nT), replace = FALSE)
    
    # form indicators of the latent IM and latent IVAR
    meanx1 <- apply(X[, index.p1], 1, mean)
    meanx2 <- apply(X[, index.p2], 1, mean)
    meanx3 <- apply(X[, index.p3], 1, mean)
    IIVx1 <- apply(X[, index.p1], 1, var)
    IIVx2 <- apply(X[, index.p2], 1, var)
    IIVx3 <- apply(X[, index.p3], 1, var)
    
    # fit the model with the latent IM and latent IVAR
    # For Lavaan model syntax, 
    # ?lavaan::model.syntax 
    
    fitdat <- data.frame(y, IIVx1, IIVx2, IIVx3, meanx1, meanx2, meanx3)
    
    model<-"
    mu =~ meanx1 + meanx2 + meanx3
    IIV =~ IIVx1 + IIVx2 + IIVx3
    y ~ start(beta_mu)*mu + start(beta_IIV)*IIV
    mu ~~ 0*IIV
    meanx1 ~ 0
    meanx2 ~ 0
    meanx3 ~ 0
    IIVx1 ~ 0
    IIVx2 ~ 0
    IIVx3 ~ 0
    mu ~ 1
    IIV ~ 1
    "
    fit <- sem(model, data = fitdat, mimic = "Mplus")
    
    est.coef.tpA <- parameterEstimates(fit)
    # Does the model fitting converge?
    fit@optim$converged
    
    # if converged, 
    # collect the estimates of the path coefficients and standard errors
    if(fit@optim$converged){
        beta_IIV.tpA[i] <- est.coef.tpA$est[8]
        se.beta_IIV.tpA[i] <- est.coef.tpA$se[8]
        beta_mu.tpA[i] <- est.coef.tpA$est[7]
        se.beta_mu.tpA[i] <- est.coef.tpA$se[7]
    }
    # if non-converge, then we would exclude this iteration   
    if( !fit@optim$converged ){
        beta_IIV.tpA[i] <- NA
        se.beta_IIV.tpA[i] <- NA
        beta_mu.tpA[i] <- NA
        se.beta_mu.tpA[i] <- NA
    }
    
}

# We aggregate the results from the allocations using the aggregation algorithm in multiple imputation (i.e., Rubin's rule).

## Let's create a little function for this aggregation, and we will use it for both IM and IIV 
aggregate.allocations <- function(beta_tpA, se_tpA) {
    ## point estimate
    Estimate <- mean(beta_tpA, na.rm = TRUE)
    
    ## total variance (TV) = U_bar + (1/m) * BV, which combines the within-allocation variance and between-allocation variance
    U_bar <- mean(se_tpA^2, na.rm=TRUE)  
    BV <- var(beta_tpA, na.rm=TRUE)
    m <- sum(!is.na(beta_tpA))
    TV <- U_bar + (1 + 1/m) * BV
    Std.Error <- sqrt(TV)
    
    ## degrees of freedom for the t-distribution
    vm <- (m - 1) * (1 + U_bar / ((1+1/m)*BV))^2
    
    CI_low <- Estimate + qt(0.025, vm) * Std.Error
    CI_high <- Estimate + qt(0.975, vm) * Std.Error
    
    data.frame(Estimate, Std.Error, CI_low, CI_high)
}

# for IM:
mu.tpA <- aggregate.allocations(beta_mu.tpA, se.beta_mu.tpA)
# for IIV:
IIV.tpA <- aggregate.allocations(beta_IIV.tpA, se.beta_IIV.tpA)
# display the results
tpA_IM_IVAR <- rbind(
    data.frame(Predictor = "IM", mu.tpA),
    data.frame(Predictor = "IVAR", IIV.tpA)
)

tpA_IM_IVAR



# IM and ISD as predictors ----
## IM: intraindividual mean
## ISD: intraindividual standard deviation

## Data ----
data_IM_ISD <- read.csv("illustration_Rscripts_data/data_IM_ISD.csv")
# outcome
y <- data_IM_ISD$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_ISD[, paste0("X.", 1:TT)]

## Run ----
# 1000 random allocations, each with 3 parcels
nA <- 1000
numpar <- 3

# create vectors to collect estimates of the path coefficients and standard errors for IM and IIV
beta_mu.tpA <- se.beta_mu.tpA  <- rep(NA, nA)
beta_IIV.tpA <- se.beta_IIV.tpA <- rep(NA, nA)

# for each random allocation
set.seed(12345)
for (i in 1:nA){
    # randomly allocate occasions to 3 parcels
    nT <- round(TT/numpar)
    index.p1 <- sample(1:TT, nT, replace = FALSE)
    temp1 <- c(1:TT)[-index.p1]
    index.p2 <- sample(temp1, nT, replace = FALSE)
    temp2 <- c(1:TT)[-c(index.p1,index.p2)]
    index.p3 <- sample(temp2, (TT - 2*nT), replace = FALSE)
    
    # form indicators of the latent IM and latent ISD
    meanx1 <- apply(X[, index.p1], 1, mean)
    meanx2 <- apply(X[, index.p2], 1, mean)
    meanx3 <- apply(X[, index.p3], 1, mean)
    IIVx1 <- apply(X[, index.p1], 1, sd)
    IIVx2 <- apply(X[, index.p2], 1, sd)
    IIVx3 <- apply(X[, index.p3], 1, sd)
    
    # fit the model with the latent IM and latent ISD
    # For Lavaan model syntax, 
    # ?lavaan::model.syntax 
    
    fitdat <- data.frame(y, IIVx1, IIVx2, IIVx3, meanx1, meanx2, meanx3)
    
    model<-"
    mu =~ meanx1 + meanx2 + meanx3
    IIV =~ IIVx1 + IIVx2 + IIVx3
    y ~ start(beta_mu)*mu + start(beta_IIV)*IIV
    mu ~~ 0*IIV
    meanx1 ~ 0
    meanx2 ~ 0
    meanx3 ~ 0
    IIVx1 ~ 0
    IIVx2 ~ 0
    IIVx3 ~ 0
    mu ~ 1
    IIV ~ 1
    "
    fit <- sem(model, data = fitdat, mimic = "Mplus")
    
    est.coef.tpA <- parameterEstimates(fit)
    # Does the model fitting converge?
    fit@optim$converged
    
    # if converged, 
    # collect the estimates of the path coefficients and standard errors
    if(fit@optim$converged){
        beta_IIV.tpA[i] <- est.coef.tpA$est[8]
        se.beta_IIV.tpA[i] <- est.coef.tpA$se[8]
        beta_mu.tpA[i] <- est.coef.tpA$est[7]
        se.beta_mu.tpA[i] <- est.coef.tpA$se[7]
    }
    # if non-converge, then we would exclude this iteration   
    if( !fit@optim$converged ){
        beta_IIV.tpA[i] <- NA
        se.beta_IIV.tpA[i] <- NA
        beta_mu.tpA[i] <- NA
        se.beta_mu.tpA[i] <- NA
    }
    
}

# We aggregate the results from the allocations using the aggregation algorithm in multiple imputation (i.e., Rubin's rule).
# (Recall that we have created a function `aggregate.allocations()` for this aggregation.) 

# for IM:
mu.tpA <- aggregate.allocations(beta_mu.tpA, se.beta_mu.tpA)
# for IIV:
IIV.tpA <- aggregate.allocations(beta_IIV.tpA, se.beta_IIV.tpA)
# display the results
tpA_IM_ISD <- rbind(
    data.frame(Predictor = "IM", mu.tpA),
    data.frame(Predictor = "ISD", IIV.tpA)
)

tpA_IM_ISD

