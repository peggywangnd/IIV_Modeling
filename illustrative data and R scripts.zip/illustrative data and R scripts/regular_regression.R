
# R script for regular regression (without bootstrapping)

# Below, we first illustrate modeling IM and IVAR as predictors, and 
# then illustrate modeling IM and ISD as predictors.


# IM and IVAR as predictors ----
## IM: intraindividual mean
## IVAR: intraindividual variance

## Data ----
data_IM_IVAR <- read.csv("illustration_Rscripts_data/data_IM_IVAR.csv")
# outcome
y <- data_IM_IVAR$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_IVAR[, paste0("X.", 1:TT)]

## Run ----

# calculate the observed IM and the observed IVAR
mu.obs <- apply(X, 1, mean)
IIV.obs <- apply(X, 1, var) 

# regress Y on the observed IM and IVAR 
regIIV <- lm(y ~ mu.obs + IIV.obs)
# take a look
summary(regIIV)

# display the results
reg_IM_IVAR <- data.frame(
    Predictor = c("IM", "IVAR"),
    Estimate = summary(regIIV)$coefficients[2:3, 1],
    Std.Error = summary(regIIV)$coefficients[2:3, 2],
    CI_low = confint(regIIV)[2:3, 1],
    CI_high = confint(regIIV)[2:3, 2]
) 

reg_IM_IVAR



# IM and ISD as predictors ----
## IM: intraindividual mean
## ISD: intraindividual standard deviation

## Data ----
data_IM_ISD <- read.csv("illustration_Rscripts_data/data_IM_ISD.csv")
# outcome
y <- data_IM_ISD$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_ISD[, paste0("X.", 1:TT)]

## Run ----

# calculate the observed IM and the observed ISD
mu.obs <- apply(X, 1, mean)
IIV.obs <- apply(X, 1, sd) 

# regress Y on the observed IM and ISD 
regIIV <- lm(y ~ mu.obs + IIV.obs)
# take a look
summary(regIIV)

# display the results
reg_IM_ISD <- data.frame(
    Predictor = c("IM", "ISD"),
    Estimate = summary(regIIV)$coefficients[2:3, 1],
    Std.Error = summary(regIIV)$coefficients[2:3, 2],
    CI_low = confint(regIIV)[2:3, 1],
    CI_high = confint(regIIV)[2:3, 2]
) 

reg_IM_ISD
