
# R script for the proposed Bayesian variability modeling approach

# We use `R2jags` package to implement the Bayesian estimation
# to install the package
# install.packages("R2jabs")
library(R2jags)

# Below, we first illustrate modeling IM and IVAR as predictors, and 
# then illustrate modeling IM and ISD as predictors.


# IM and IVAR as predictors ----
## IM: intraindividual mean
## IVAR: intraindividual variance

## Data ----
data_IM_IVAR <- read.csv("illustration_Rscripts_data/data_IM_IVAR.csv")
# outcome
y <- data_IM_IVAR$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_IVAR[, paste0("X.", 1:TT)]

## Run ----

# To help identify the model, we use information of the measurement scale reliability of predictor X
ReMeasure <- 0.88

# the jags model
cat("
    model {
            
            for(i in 1:N){
            for(j in 1:J){
            # x_it = mu_i + v_it + e_it
            X[i,j] ~ dnorm(mux[i], taux[i])
            }
            mux[i] ~ dnorm(mu_mux, tau_mux)
            taux[i] <- 1/(sigmasq_v[i] + sigmasq_e)
            
            # we model the true intraindividual variance `sigmasq_v[i]` to follow a gamma distribution
        
            sigmasq_v[i] ~ dgamma(shape_v, rate_v)
            sigma_v[i] <- sqrt(sigmasq_v[i])
            
            # we model the outcome to follow a normal distribution
            y[i] ~ dnorm(muy[i], tauy)
            muy[i] <- beta0 + beta1*mux[i] + beta2*sigmasq_v[i]
            }
            
            
            # priors for the X model
            mu_mux ~ dnorm(0, 1e-6)
            
            sigma_mux ~ dt(0, pow(100,-2), 1) T(0,)
            sigmasq_mux <- sigma_mux^2
            tau_mux <- 1/sigmasq_mux 

            shape_v ~ dt(0, pow(100,-2), 1) T(0,)
            rate_v ~ dt(0, pow(100,-2), 1) T(0,)
            scale_v <- 1/rate_v
            
            # we set the measurement error variance `sigmasq_e` using the measurement scale reliability `ReMeasure`, according to the derivation results from Wang and Grimm (2012)
            
            sigmasq_e <- (1-ReMeasure)/ReMeasure * (1/tau_mux + shape_v/rate_v)
            
            # priors for the outcome model coefficients
            beta0 ~ dnorm(0, 1e-6)
            beta1 ~ dnorm(0, 1e-6)
            beta2 ~ dnorm(0, 1e-6)
            sigma_y ~ dt(0, pow(100,-2), 1) T(0,)
            sigmasq_y <- sigma_y^2
            tauy <- 1/sigmasq_y
            
            
            }  ", 
          file = "illustration_Rscripts_data/JAGS_IVAR.txt")

# jags data
jagsdat <- list(
    N = nrow(X), # sample size
    J = ncol(X), # number of occasions
    X = X,
    y = y,
    ReMeasure = ReMeasure
)

# run jags
set.seed(12345)
jagsout <- jags(
    data = jagsdat, 
    parameters.to.save = c("beta1", "beta2"), 
    model.file = "illustration_Rscripts_data/JAGS_IVAR.txt", 
    n.chains = 2,
    n.iter = 20000)

# check trace plot
traceplot(jagsout)

# extract the results
jagsres <- jagsout$BUGSoutput$summary

# check Rhat (Gelman-Rubin statistic) to assess the convergence. Rhat < 1.1 indicates convergence.
jagsres[, "Rhat"]

# display the results
Bayes_IM_IVAR <- data.frame(
    Predictor = c("IM", "IVAR"),
    Estimate = jagsres[1:2, "mean"],
    Std.Error = jagsres[1:2, "sd"],
    CI_low = jagsres[1:2, "2.5%"],
    CI_high = jagsres[1:2, "97.5%"]
) 

Bayes_IM_IVAR


# IM and ISD as predictors ----
## IM: intraindividual mean
## ISD: intraindividual standard deviation


## Data ----
data_IM_ISD <- read.csv("illustration_Rscripts_data/data_IM_ISD.csv")
# outcome
y <- data_IM_ISD$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_ISD[, paste0("X.", 1:TT)]

## Run ----

# To help identify the model, we use information of the measurement scale reliability of the predictor X
ReMeasure <- 0.88

# the jags model
cat("
    model {
            
            for(i in 1:N){
            for(j in 1:J){
            # x_it = mu_i + v_it + e_it
            X[i,j] ~ dnorm(mux[i], taux[i])
            }
            mux[i] ~ dnorm(mu_mux, tau_mux)
            taux[i] <- 1/(sigmasq_v[i] + sigmasq_e)
            
            # we model the true intraindividual variance `sigmasq_v[i]` to follow a gamma distribution
        
            sigmasq_v[i] ~ dgamma(shape_v, rate_v)
            sigma_v[i] <- sqrt(sigmasq_v[i])
            
            # we model the outcome to follow a normal distribution
            y[i] ~ dnorm(muy[i], tauy)
            muy[i] <- beta0 + beta1*mux[i] + beta2*sigma_v[i]
            }
            
            
            # priors for the X model
            mu_mux ~ dnorm(0, 1e-6)
            
            sigma_mux ~ dt(0, pow(100,-2), 1) T(0,)
            sigmasq_mux <- sigma_mux^2
            tau_mux <- 1/sigmasq_mux 

            shape_v ~ dt(0, pow(100,-2), 1) T(0,)
            rate_v ~ dt(0, pow(100,-2), 1) T(0,)
            scale_v <- 1/rate_v
            
            # we set the measurement error variance `sigmasq_e` using the measurement scale reliability `ReMeasure`, according to the derivation results from Wang and Grimm (2012)
            
            sigmasq_e <- (1-ReMeasure)/ReMeasure * (1/tau_mux + shape_v/rate_v)
            
            # priors for the outcome model coefficients
            beta0 ~ dnorm(0, 1e-6)
            beta1 ~ dnorm(0, 1e-6)
            beta2 ~ dnorm(0, 1e-6)
            sigma_y ~ dt(0, pow(100,-2), 1) T(0,)
            sigmasq_y <- sigma_y^2
            tauy <- 1/sigmasq_y
            
            
            }  ", 
             file = "illustration_Rscripts_data/JAGS_ISD.txt")

# jags data
jagsdat <- list(
    N = nrow(X), # sample size
    J = ncol(X), # number of occasions
    X = X,
    y = y,
    ReMeasure = ReMeasure
)

# run jags
set.seed(12345)
jagsout <- jags(
    data = jagsdat, 
    parameters.to.save = c("beta1", "beta2"), 
    model.file = "illustration_Rscripts_data/JAGS_ISD.txt", 
    n.chains = 2,
    n.iter = 20000)

# check trace plot
traceplot(jagsout)

# extract the results
jagsres <- jagsout$BUGSoutput$summary

# check Rhat (Gelman-Rubin statistic) to assess the convergence. Rhat < 1.1 indicates convergence.
jagsres[, "Rhat"]

# display the results
Bayes_IM_ISD <- data.frame(
    Predictor = c("IM", "ISD"),
    Estimate = jagsres[1:2, "mean"],
    Std.Error = jagsres[1:2, "sd"],
    CI_low = jagsres[1:2, "2.5%"],
    CI_high = jagsres[1:2, "97.5%"]
) 

Bayes_IM_ISD

