
# R script for single indicator latent variable modeling (without bootstrapping)

# In this illustration, we use the `lavaan` package to fit the model with latent IM and latent IIV.
# to install the package: 
# install.packages("lavaan")
library(lavaan)

# Below, we first illustrate modeling IM and IVAR as predictors, and 
# then illustrate modeling IM and ISD as predictors.


# IM and IVAR as predictors ----
## IM: intraindividual mean
## IVAR: intraindividual variance

## Data ----
data_IM_IVAR <- read.csv("illustration_Rscripts_data/data_IM_IVAR.csv")
# outcome
y <- data_IM_IVAR$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_IVAR[, paste0("X.", 1:TT)]

## Run ----
# calculate the observed IM as the single indicator of the latent IM
mu.obs <- apply(X, 1, mean) 
# calculate the observed IVAR as the single indicator of the latent IVAR
IIV.obs <- apply(X, 1, var)

# obtain the reliability estimates following Wang and Grimm (2012) 
## (see Eq. 8 for the reliability for IM, Eq. 13 for the reliability for IVAR.)
Vx <- var(as.vector(as.matrix(X)))
Vm <- var(mu.obs)
VISD2 <- var(IIV.obs)
T_1 <- TT/(TT-1)

sigmae2.hat <- Vx*(1-0.88) # 0.88 is the known measurement scale reliability of X
sigmae.hat <- sqrt(sigmae2.hat)
abhat <- T_1*(Vx-Vm) - sigmae2.hat
b.hat <- (VISD2 - 4*sigmae2.hat*abhat/(TT-1) - 2*(sigmae2.hat^2+abhat^2)/(TT-1))/(abhat+2*abhat/(TT-1))
a.hat <- abhat/b.hat    
sigmamu2.hat <- T_1*Vm - Vx/(TT-1)

# reliability for IM
trmean <- sigmamu2.hat/(sigmamu2.hat + 1/TT*(a.hat*b.hat) + 1/TT*sigmae.hat^2)
# reliability for IVAR
trisd2 <- a.hat*b.hat^2/(a.hat*b.hat^2 + 2/(TT-1)*(a.hat^2*b.hat^2+a.hat*b.hat^2) + 2/(TT-1)*sigmae.hat^4 + 4/(TT-1)*a.hat*b.hat*sigmae.hat^2)

# calculate the error variances of the observed IM and IVAR scores, which will be fixed for fitting the single indicator latent variable model
vres.meanx <- (1 - trmean)*var(mu.obs)
vres.IIVx <- (1 - trisd2)*var(IIV.obs)

# fit the single indicator latent variable model
fitdat <- data.frame(y, IIV.obs, mu.obs)

model <- paste0('
  mu =~ 1*mu.obs
  IIV =~ 1*IIV.obs
  y ~ start(beta_mu)*mu + start(beta_IIV)*IIV
  mu ~~ 0*IIV
  mu.obs ~ 0
  IIV.obs ~ 0
  mu ~ 1
  IIV ~ 1
  mu.obs ~~', vres.meanx,'*mu.obs
  IIV.obs ~~', vres.IIVx,'*IIV.obs')

fit <- sem(model, data=fitdat, mimic="Mplus")
# summary(fit)

# extract the parameter estimates and standard error estimates
est.coef.SI <- parameterEstimates(fit)

# display the results 
SI_IM_IVAR <- data.frame(
    Predictor = c("IM", "IVAR"),
    Estimate = est.coef.SI$est[c(3, 4)],
    Std.Error = est.coef.SI$se[c(3, 4)],
    CI_low = est.coef.SI$ci.lower[c(3, 4)],
    CI_high = est.coef.SI$ci.upper[c(3, 4)]
) 

SI_IM_IVAR




# IM and ISD as predictors ----
## IM: intraindividual mean
## ISD: intraindividual standard deviation

## Data ----
data_IM_ISD <- read.csv("illustration_Rscripts_data/data_IM_ISD.csv")
# outcome
y <- data_IM_ISD$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_ISD[, paste0("X.", 1:TT)]

## Run ----
# calculate the observed IM as the single indicator of the latent IM
mu.obs <- apply(X, 1, mean) 
# calculate the observed ISD as the single indicator of the latent ISD
IIV.obs <- apply(X, 1, sd)

# obtain the reliability estimates following Wang and Grimm (2012) 
## (see Eq. 8 for the reliability for IM, and Eq. 19 for the reliability for ISD.)
Vx <- var(as.vector(as.matrix(X)))
Vm <- var(mu.obs)
ISD2.obs <- apply(X, 1, var)
VISD2 <- var(ISD2.obs)
T_1 <- TT/(TT-1)

sigmae2.hat <- Vx*(1 - 0.88)#  0.88 is the known measurement scale reliability of X
sigmae.hat <- sqrt(sigmae2.hat)
abhat <- T_1*(Vx-Vm) - sigmae2.hat
b.hat <- (VISD2 - 4*sigmae2.hat*abhat/(TT-1) -2*(sigmae2.hat^2+abhat^2)/(TT-1))/(abhat + 2*abhat/(TT-1))
a.hat <- abhat/b.hat
sigmamu2.hat <- T_1*Vm - Vx/(TT-1)

# reliability for IM 
trmean <- sigmamu2.hat/(sigmamu2.hat + 1/TT*(a.hat*b.hat) + 1/TT*sigmae.hat^2)

# reliability for ISD
sigmav2 <- rgamma(100000,shape=a.hat,scale=b.hat)

cn <- sqrt(2/(TT-1))*(gamma(TT/2)/gamma((TT-1)/2))
trisdnum <- cn^2*(mean(sqrt(sigmav2 + sigmae.hat^2)*sqrt(sigmav2)) - mean(sqrt(sigmav2 + sigmae.hat^2))*mean(sqrt(sigmav2)))^2
trisdden <- (a.hat*b.hat + sigmae.hat^2 - cn^2*(mean(sqrt(sigmav2+sigmae.hat^2)))^2)*(a.hat*b.hat - mean(sqrt(sigmav2))^2)
trisd <- trisdnum/trisdden

# calculate the error variances of the observed IM and ISD scores, which will be fixed for fitting the single indicator latent variable model
vres.meanx <- (1-trmean)*var(mu.obs)
vres.IIVx <- (1-trisd)*var(IIV.obs)

# fit the single indicator latent variable model
fitdat <- data.frame(y, IIV.obs, mu.obs)

model <- paste0('
  mu =~ 1*mu.obs
  IIV =~ 1*IIV.obs
  y ~ start(beta_mu)*mu + start(beta_IIV)*IIV
  mu ~~ 0*IIV
  mu.obs ~ 0
  IIV.obs ~ 0
  mu ~ 1
  IIV ~ 1
  mu.obs ~~', vres.meanx,'*mu.obs
  IIV.obs ~~', vres.IIVx,'*IIV.obs')

fit <- sem(model, data=fitdat, mimic="Mplus")
# summary(fit)

# extract the parameter estimates and standard error estimates
est.coef.SI <- parameterEstimates(fit)

# display the results 
SI_IM_ISD <- data.frame(
    Predictor = c("IM", "ISD"),
    Estimate = est.coef.SI$est[c(3, 4)],
    Std.Error = est.coef.SI$se[c(3, 4)],
    CI_low = est.coef.SI$ci.lower[c(3, 4)],
    CI_high = est.coef.SI$ci.upper[c(3, 4)]
) 

SI_IM_ISD

