
# R script for time parceling with bootstrapping

# In this illustration, we form numpar = 3 parcels. We use the `lavaan` package to fit the model with latent IM and latent IIV.
# to install the package: 
# install.packages("lavaan")
library(lavaan)

# Below, we first illustrate modeling IM and IVAR as predictors, and 
# then illustrate modeling IM and ISD as predictors.


# IM and IVAR as predictors ----
## IM: intraindividual mean
## IVAR: intraindividual variance

## Data ----
data_IM_IVAR <- read.csv("illustration_Rscripts_data R1/data_IM_IVAR.csv")
# outcome
y <- data_IM_IVAR$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_IVAR[, paste0("X.", 1:TT)]

## Run ----
# 1000 bootstrap samples, each with 3 parcels
n_bootstrap <- 1000
numpar <- 3
Tper <- TT/numpar

# create a matrix to collect the estimates of the path coefficients for IM and IVAR across all bootstrap samples. 
betas_tpB <- matrix(NA, nrow = n_bootstrap, ncol = 2)
colnames(betas_tpB) <- c("IM", "IVAR")

# for each bootstrap sample
set.seed(12345)
for (B in 1:n_bootstrap){
    index <- sample(1:nrow(X), nrow(X), replace = TRUE)
    XB <- X[index,]
    yB <- y[index]
    
    indexC <- rep(1:numpar, each = Tper)
    mean <- IIV <- NULL
    for(i in 1:numpar){
        x <- XB[, indexC==i]
        IIV[[i]] <- apply(x,1,var)
        mean[[i]] <- apply(x,1,mean)
    }
    IIVx1 <- IIV[[1]]    
    IIVx2 <- IIV[[2]]    
    IIVx3 <- IIV[[3]]  
    meanx1 <- mean[[1]]
    meanx2 <- mean[[2]]
    meanx3 <- mean[[3]]
    
    # fit the model with the latent IM and latent IVAR using the bootstrap sample
    # For Lavaan model syntax,
    # lavaan::model.syntax
    
    fitdat <- data.frame(yB, IIVx1, IIVx2, IIVx3, meanx1, meanx2, meanx3)
    
    # allow correlated IM and IIV   ----
    
    model<-"
    mu =~ meanx1 + meanx2 + meanx3
    IIV =~ IIVx1 + IIVx2 + IIVx3
    yB ~ mu + IIV
    mu ~~ IIV
    meanx1 ~ 0
    meanx2 ~ 0
    meanx3 ~ 0
    IIVx1 ~ 0
    IIVx2 ~ 0
    IIVx3 ~ 0
    mu ~ 1
    IIV ~ 1
    "
    fit <- sem(model, data = fitdat, mimic = "Mplus")
    
    est.coef.tpB <- parameterEstimates(fit)
    # Does the model fitting converge?
    fit@optim$converged
    
    # if converged,
    # collect the estimates of the path coefficients
    if(fit@optim$converged){
        betas_tpB[B, ] <- est.coef.tpB$est[c(7, 8)]
    }
    # if non-converge, then we would exclude this iteration
    if( !fit@optim$converged ){
        betas_tpB[B, ] <- NA
    }
    
}


# obtain the results by summarizing the coefficient estimates across bootstrap samples
tpB_IM_IVAR <- data.frame(
    Predictor = c("IM", "IVAR"),
    Estimate = apply(betas_tpB, 2, mean, na.rm = TRUE),
    Std.Error = apply(betas_tpB, 2, sd, na.rm = TRUE),
    CI_low = apply(betas_tpB, 2, quantile, 0.025, na.rm = TRUE),
    CI_high = apply(betas_tpB, 2, quantile, 0.975, na.rm = TRUE),
    Converge = mean(complete.cases(betas_tpB))
) 

tpB_IM_IVAR




# IM and ISD as predictors ----
## IM: intraindividual mean
## ISD: intraindividual standard deviation

## Data ----
data_IM_ISD <- read.csv("illustration_Rscripts_data R1/data_IM_ISD.csv")
# outcome
y <- data_IM_ISD$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_ISD[, paste0("X.", 1:TT)]

## Run ----
# 1000 bootstrap samples, each with 3 parcels
n_bootstrap <- 1000
numpar <- 3
Tper <- TT/numpar

# create a matrix to collect the estimates of the path coefficients for IM and ISD across all bootstrap samples. 
betas_tpB <- matrix(NA, nrow = n_bootstrap, ncol = 2)
colnames(betas_tpB) <- c("IM", "ISD")

# for each bootstrap sample
set.seed(12345)
for (B in 1:n_bootstrap){
    index <- sample(1:nrow(X), nrow(X), replace = TRUE)
    XB <- X[index,]
    yB <- y[index]
    
      
    indexC <- rep(1:numpar, each = Tper)
    mean <- IIV <- NULL
    for(i in 1:numpar){
        x <- XB[, indexC==i]
        IIV[[i]] <- apply(x,1,sd)
        mean[[i]] <- apply(x,1,mean)
    }
    IIVx1 <- IIV[[1]]    
    IIVx2 <- IIV[[2]]    
    IIVx3 <- IIV[[3]]  
    meanx1 <- mean[[1]]
    meanx2 <- mean[[2]]
    meanx3 <- mean[[3]]
    
    
    
    # fit the model with the latent IM and latent IVAR using the bootstrap sample
    # For Lavaan model syntax,
    # lavaan::model.syntax
    
    fitdat <- data.frame(yB, IIVx1, IIVx2, IIVx3, meanx1, meanx2, meanx3)
    
    # allow correlated IM and IIV   ----
    
    model<-"
    mu =~ meanx1 + meanx2 + meanx3
    IIV =~ IIVx1 + IIVx2 + IIVx3
    yB ~ mu + IIV
    mu ~~ IIV
    meanx1 ~ 0
    meanx2 ~ 0
    meanx3 ~ 0
    IIVx1 ~ 0
    IIVx2 ~ 0
    IIVx3 ~ 0
    mu ~ 1
    IIV ~ 1
    "
    fit <- sem(model, data = fitdat, mimic = "Mplus")
    
    est.coef.tpB <- parameterEstimates(fit)
    # Does the model fitting converge?
    fit@optim$converged
    
    # if converged,
    # collect the estimates of the path coefficients
    if(fit@optim$converged){
        betas_tpB[B, ] <- est.coef.tpB$est[c(7, 8)]
    }
    # if non-converge, then we would exclude this iteration
    if( !fit@optim$converged ){
        betas_tpB[B, ] <- NA
    }
    
}



# obtain the results by summarizing the coefficient estimates across bootstrap samples
tpB_IM_ISD <- data.frame(
    Predictor = c("IM", "ISD"),
    Estimate = apply(betas_tpB, 2, mean, na.rm = TRUE),
    Std.Error = apply(betas_tpB, 2, sd, na.rm = TRUE),
    CI_low = apply(betas_tpB, 2, quantile, 0.025, na.rm = TRUE),
    CI_high = apply(betas_tpB, 2, quantile, 0.975, na.rm = TRUE),
    Converge = mean(complete.cases(betas_tpB))
) 

tpB_IM_ISD

