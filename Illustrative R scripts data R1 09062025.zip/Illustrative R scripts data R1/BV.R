
# R script for the Bayesian variability modeling

# We use `runjags` package to implement the Bayesian estimation
# to install the package
# install.packages("runjags")
library(runjags)

# Below, we first illustrate modeling IM and IVAR as predictors, and 
# then illustrate modeling IM and ISD as predictors.


# IM and IVAR as predictors ----
## IM: intraindividual mean
## IVAR: intraindividual variance

## Data ----
data_IM_IVAR <- read.csv("data_IM_IVAR.csv")
# outcome
y <- data_IM_IVAR$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_IVAR[, paste0("X.", 1:TT)]

## Run ----

# the jags model file
model_file <- "JAGS_IVAR.txt"

# jags data
jagsdat <- list(
    N = nrow(X), # sample size
    J = ncol(X), # number of occasions
    X = as.matrix(X),
    y = y
)

# use estimates from regular regression to specify initial values
mu.obs <- apply(X, 1, mean)
IIV.obs <- apply(X, 1, var) 
regIIV <- lm(y ~ mu.obs + IIV.obs)

inits <- list(
    list(beta2 = summary(regIIV)$coefficients["IIV.obs", "Estimate"], 
         beta1 = summary(regIIV)$coefficients["mu.obs", "Estimate"]),
    list(beta2 = summary(regIIV)$coefficients["IIV.obs", "Estimate"] + summary(regIIV)$coefficients["IIV.obs", "Std. Error"], 
         beta1 = summary(regIIV)$coefficients["mu.obs", "Estimate"] + summary(regIIV)$coefficients["mu.obs", "Std. Error"])
)

# run jags
set.seed(12345)
jagsout <- runjags::run.jags(
    model = model_file,
    monitor = c("beta1", "beta2"),
    data = jagsdat,
    n.chains = 2,
    inits = inits, 
    method = "simple", 
    adapt = 10000, 
    burnin = 20000, 
    sample = 8000, 
    thin = 10, keep.jags.files = FALSE
)

# extract the results
jagsres <- summary(jagsout)

# check potential scale reduction factor (PSRF) to assess the convergence. PSRF < 1.1 indicates convergence.
jagsres[, "psrf"]

# display the results
Bayes_IM_IVAR <- data.frame(
    Estimand = c("beta1", "beta2"),
    Estimate = jagsres[1:2, "Mean"],
    Std.Error = jagsres[1:2, "SD"],
    CI_low = jagsres[1:2, "Lower95"],
    CI_high = jagsres[1:2, "Upper95"],
    Converge = jagsres[1:2, "psrf"]
)

Bayes_IM_IVAR


# IM and ISD as predictors ----
## IM: intraindividual mean
## ISD: intraindividual standard deviation

## Data ----
data_IM_ISD <- read.csv("data_IM_ISD.csv")
# outcome
y <- data_IM_ISD$Y
# number of occasions (known from the study design)
TT <- 56
# wide-format data of the predictor X
X <- data_IM_ISD[, paste0("X.", 1:TT)]

## Run ----

# the jags model file
model_file <- "JAGS_ISD.txt"

# jags data
jagsdat <- list(
    N = nrow(X), # sample size
    J = ncol(X), # number of occasions
    X = as.matrix(X),
    y = y
)

# use estimates from regular regression to specify initial values
mu.obs <- apply(X, 1, mean)
IIV.obs <- apply(X, 1, sd) 
regIIV <- lm(y ~ mu.obs + IIV.obs)

inits <- list(
    list(beta2 = summary(regIIV)$coefficients["IIV.obs", "Estimate"], 
         beta1 = summary(regIIV)$coefficients["mu.obs", "Estimate"]),
    list(beta2 = summary(regIIV)$coefficients["IIV.obs", "Estimate"] + summary(regIIV)$coefficients["IIV.obs", "Std. Error"], 
         beta1 = summary(regIIV)$coefficients["mu.obs", "Estimate"] + summary(regIIV)$coefficients["mu.obs", "Std. Error"])
)

# run jags
set.seed(12345)
jagsout <- runjags::run.jags(
    model = model_file,
    monitor = c("beta1", "beta2"),
    data = jagsdat,
    n.chains = 2,
    inits = inits, 
    method = "simple", 
    adapt = 10000, 
    burnin = 20000, 
    sample = 8000, 
    thin = 10, keep.jags.files = FALSE
)


# extract the results
jagsres <- summary(jagsout)

# check potential scale reduction factor (PSRF) to assess the convergence. PSRF < 1.1 indicates convergence.
jagsres[, "psrf"]


# display the results
Bayes_IM_ISD <- data.frame(
    Estimand = c("beta1", "beta2"),
    Estimate = jagsres[1:2, "Mean"],
    Std.Error = jagsres[1:2, "SD"],
    CI_low = jagsres[1:2, "Lower95"],
    CI_high = jagsres[1:2, "Upper95"],
    Converge = jagsres[1:2, "psrf"]
)

Bayes_IM_ISD

